# Tensorlite

#### Tensorflow's lightest & minimalist edition !

![image](/assets/images.jpg)

Tensorlite is a very light and minimal edition of Tensorflow. Main motive of the __TENSORLITE__ project, is to actually make people understand the inner workings of Tensorflow and Deep Learning. This light and minimal edition , despite being small and light , comes with all the main features packed into it. Dont go on its size. This light framework is powerful enough to power any small to mid-range tasks, where you feel the need of tensorflow , but do not want to use something that heavy. __Hope you have a great journey aboard__ .